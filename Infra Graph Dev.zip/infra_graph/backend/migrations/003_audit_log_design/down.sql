DROP TABLE audit_log;
