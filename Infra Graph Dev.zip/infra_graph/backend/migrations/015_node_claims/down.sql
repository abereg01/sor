-- 015_node_claims/down.sql

DROP TABLE IF EXISTS node_claims;
