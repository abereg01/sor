DROP INDEX IF EXISTS ux_edges_from_to_kind;
DROP INDEX IF EXISTS ux_nodes_kind_name;

