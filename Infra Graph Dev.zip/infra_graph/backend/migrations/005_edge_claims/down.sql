-- 005_edge_claims/down.sql
DROP TABLE IF EXISTS edge_claims;
